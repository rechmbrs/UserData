RONC Photoshop Scripts and Plugins

Files:
	*.jsxbin   insert in Photoshop script folder with many *.jsx already present
	*.pdf       same location
	*.8bf       insert in Windows Photoshop plugin folder with many *.8bf already present
	*.dll        insert in Windows Photoshop root folder with Photoshop.exe already present
	*.atn       insert in Photoshop actions folder with many *.atn already present
	*.plugin  insert in MAC Photoshop plugin folder with many *.plugin already present
	
None of the plugins are designed to run from the Filter menu of Photoshop.  
They designed be executed by one of the scripts (*.jsxbin).  
The *.pdf files are documentation on how to use the script.	

RONC rechmbrs at gmail.com